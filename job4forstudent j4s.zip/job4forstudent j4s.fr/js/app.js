$(document).ready(function() {
    $(".fun").hover(function(){
        $(this).css("font-family", "fantasy");
    }, function(){
        $(this).css("font-family", "Monospace");
    });
});0
